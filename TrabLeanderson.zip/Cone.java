package yuri;

public class Cone {

    public static void main(String[] args) {

        // Fórmula para Calcular o Volume do Cone           
        int V = 0, R = 15, H = 17, Tt = 3;

        V = (Tt * (R * 2) * H ) / 3;

        System.err.println("Calcule a volume do Cone:  \n"+V);

    }
}
