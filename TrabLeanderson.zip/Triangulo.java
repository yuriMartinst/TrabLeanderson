package yuri;

public class Triangulo {

    public static void main(String[] args) {

        // Fórmula para Calcular o volume do triângulo:
        int V = 0, Base = 16, Altura = 10;

        V = Base * Altura / 3;

        System.err.println("volume do triângulo:  \n" + V);

    }

}
