package yuri;

public class Cubo {

    public static void main(String[] args) {

        // Fórmula para Calcular o Volume do Cubo        
        // V: equivale à medida do volume do cubo
        // A: equivale à medida da aresta do cubo
        
        int V = 0, A = 13;
        V = A * A * A;

        System.err.println("Calcule a volume do Cubo:  \n"+V);

    }

}
