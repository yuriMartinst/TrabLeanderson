package yuri;

public class Paralelepipedo {

    public static void main(String[] args) {

        //  Fórmula para Calcular o volume do Paralelepipedo:
        int V = 0, Base = 16, Altura = 10, Largura = 17;

        V = Base * Altura * Largura;

        System.err.println("volume do Paralelepipedo:  \n" + V);

    }
}
